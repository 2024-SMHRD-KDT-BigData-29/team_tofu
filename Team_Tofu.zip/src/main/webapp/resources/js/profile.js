// 뒤로가기 버튼 기능
document.getElementById('back-button').addEventListener('click', function() {
    alert('뒤로가기 버튼이 클릭되었습니다.'); // 실제로는 페이지 이동 또는 다른 동작을 구현
});

// 프로필 수정 버튼 기능
document.getElementById('edit-profile-button').addEventListener('click', function() {
    alert('프로필 수정 페이지로 이동합니다.'); // 실제로는 프로필 수정 페이지로 이동
});

// 게시글 보기 버튼 기능
document.getElementById('view-posts-button').addEventListener('click', function() {
    alert('게시글 페이지로 이동합니다.'); // 실제로는 게시글 페이지로 이동
});

// 프로필 보기 버튼 기능
document.getElementById('view-profile-button').addEventListener('click', function() {
    alert('프로필 페이지로 이동합니다.'); // 실제로는 프로필 페이지로 이동
});